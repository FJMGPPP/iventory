package com.fjmg.inventory.base;

public interface IProgressView
{
    void hideProgress();
    void showProgress();
}
